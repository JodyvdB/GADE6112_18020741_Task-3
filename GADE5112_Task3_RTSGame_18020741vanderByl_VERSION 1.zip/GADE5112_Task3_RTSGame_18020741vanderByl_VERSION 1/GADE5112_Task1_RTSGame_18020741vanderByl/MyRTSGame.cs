﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GADE5112_Task1_RTSGame_18020741vanderByl
{
    public partial class frmRTSMain : Form
    {
        // Creating a GameEngine object.
        GameEngine engine;
        Map myMap = new Map(); 
        //FactoryBuilding fB;
        //ResourceBuilding rB;
        //RangedUnit rU;
        //MeleeUnit mU;
        int count = 0;
        Random rand = new Random();

        public frmRTSMain()
        {
            InitializeComponent();
        }

        // When the form is loaded, the engine object is instantiated.
        private void frmRTSMain_Load(object sender, EventArgs e)
        {
            int randomX = rand.Next(10, 101);
            int randomY = rand.Next(10, 101);
            engine = new GameEngine(this, grpBxInfo);
            engine.setRandomMap(randomX, randomY);
        }

        // Whenever a tick happens in the timer, the timestamp is updated and the entire board of units is updated and moved.
        private void tmrGameTime_Tick(object sender, EventArgs e)
        {
            engine.updateMap();
            engine.updateDisplay();
            lblTimeStamp.Text = (++count).ToString();
        }

        // Method that adds a string to the listbox.
        public void displayInfo(string msg)
        {
            lstBxUnitInfo.Items.Add(msg);
        }

        // When the exit button is clicked, the form is closed and the program ends.
        private void btnExit_Click(object sender, EventArgs e)
        {
            tmrGameTime.Enabled = false;
            Environment.Exit(0);
        }

        // When the play button is clicked, the timer starts/continues and the simulation begins.
        private void btnPlay_Click(object sender, EventArgs e)
        {
            tmrGameTime.Enabled = true;
            engine.updateMap();
            engine.updateDisplay();
            lblTimeStamp.Text = (++count).ToString();
        }

        // When the pause button is clicked, the timer is disabled (keeping its value of time) until play is clicked again.
        private void btnPause_Click(object sender, EventArgs e)
        {
            tmrGameTime.Enabled = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            foreach (Unit u in myMap.units)
            {
                if (u.GetType() == typeof(MeleeUnit))
                {
                    u.save(docPath);

                }
                else if (u.GetType() == typeof(RangedUnit))
                {
                    u.save(docPath);
                }
            }

            foreach (Building b in myMap.buildings)
            {
                b.save(docPath);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            myMap.read(docPath);
        }
    }
}
