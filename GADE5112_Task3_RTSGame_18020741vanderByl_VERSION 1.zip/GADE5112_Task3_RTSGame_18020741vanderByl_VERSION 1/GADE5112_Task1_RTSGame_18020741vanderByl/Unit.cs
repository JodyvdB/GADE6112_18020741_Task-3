﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GADE5112_Task1_RTSGame_18020741vanderByl
{
    // Abstract class means that no implementation is placed in any of the methods placed in this class.
    abstract class Unit
    {
        // Protected variables are used here to keep them private to the parent and child classes only.
        protected int xPos, yPos, maxHealth, health, speed, attack, attackRange, team;
        protected string symbol;

        // Abstract accessors and mutators for each variable. These methods allow the variables to be accessed without having access to the variables themselves.
        public abstract int XPos
        {
            get;
            set;
        }

        public abstract int YPos
        {
            get;
            set;
        }

        public abstract int MaxHealth
        {
            get;
            set;
        }

        public abstract int Health
        {
            get;
            set;
        }

        public abstract int Speed
        {
            get;
            set;
        }

        public abstract int Attack
        {
            get;
            set;
        }

        public abstract int AttackRange
        {
            get;
            set;
        }

        public abstract int Team
        {
            get;
            set;
        }

        public abstract string Symbol
        {
            get;
            set;
        }

        // These abstract methods do not contain any code inside, only the header is accessible. These abstract methods are here
        // so that all child classes can then inherit and override the methods and include code in them in the needed context.
        public abstract void move(ref Unit closestUnit, ref Building closestBuilding, int maxX, int maxY);

        public abstract void combat(ref Unit attacker);

        public abstract bool isInRange(ref Unit attacker);

        public abstract Unit closestUnit(ref Unit[] map);

        public abstract Building closestBuilding(ref Building[] map);

        public abstract string toString();

        public abstract void death();

        public abstract void save(string docPath);

    }
}
