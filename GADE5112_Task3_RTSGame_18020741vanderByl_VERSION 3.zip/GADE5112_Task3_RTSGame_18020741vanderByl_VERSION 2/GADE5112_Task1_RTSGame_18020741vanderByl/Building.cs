﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GADE5112_Task1_RTSGame_18020741vanderByl
{
    abstract class Building
    {
        protected int x, y, hp, maxHP, team, symbol;

        // Accessors and mutators for variables.
        public abstract int X
        {
            get;
            set;
        }

        public abstract int Y
        {
            get;
            set;
        }

        public abstract int HP
        {
            get;
            set;
        }

        public abstract int MaxHP
        {
            get;
            set;
        }

        public abstract int Team
        {
            get;
            set;
        }

        public abstract int Symbol
        {
            get;
            set;
        }

        // abstract methods
        public abstract string toString();

        public abstract void death();

        public abstract void save(string docPath);
    }
}
