﻿namespace GADE5112_Task1_RTSGame_18020741vanderByl
{
    partial class frmRTSMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRTSMain));
            this.lblElapsedTime = new System.Windows.Forms.Label();
            this.lblTimeStamp = new System.Windows.Forms.Label();
            this.imgLstIcons = new System.Windows.Forms.ImageList(this.components);
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnPause = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.tmrGameTime = new System.Windows.Forms.Timer(this.components);
            this.grpBxInfo = new System.Windows.Forms.GroupBox();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lstBxUnitInfo = new System.Windows.Forms.ListBox();
            this.grpBxInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblElapsedTime
            // 
            this.lblElapsedTime.AutoSize = true;
            this.lblElapsedTime.Font = new System.Drawing.Font("ROG Fonts", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblElapsedTime.Location = new System.Drawing.Point(4, 15);
            this.lblElapsedTime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblElapsedTime.Name = "lblElapsedTime";
            this.lblElapsedTime.Size = new System.Drawing.Size(229, 26);
            this.lblElapsedTime.TabIndex = 1;
            this.lblElapsedTime.Text = "Elapsed Time:";
            // 
            // lblTimeStamp
            // 
            this.lblTimeStamp.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblTimeStamp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTimeStamp.Font = new System.Drawing.Font("ROG Fonts", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimeStamp.Location = new System.Drawing.Point(230, 15);
            this.lblTimeStamp.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTimeStamp.Name = "lblTimeStamp";
            this.lblTimeStamp.Size = new System.Drawing.Size(112, 29);
            this.lblTimeStamp.TabIndex = 2;
            // 
            // imgLstIcons
            // 
            this.imgLstIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgLstIcons.ImageStream")));
            this.imgLstIcons.TransparentColor = System.Drawing.Color.Transparent;
            this.imgLstIcons.Images.SetKeyName(0, "Exit.png");
            this.imgLstIcons.Images.SetKeyName(1, "Pause.png");
            this.imgLstIcons.Images.SetKeyName(2, "Start.png");
            // 
            // btnPlay
            // 
            this.btnPlay.ImageKey = "Start.png";
            this.btnPlay.ImageList = this.imgLstIcons;
            this.btnPlay.Location = new System.Drawing.Point(9, 293);
            this.btnPlay.Margin = new System.Windows.Forms.Padding(2);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(75, 81);
            this.btnPlay.TabIndex = 4;
            this.btnPlay.UseVisualStyleBackColor = true;
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnPause
            // 
            this.btnPause.ImageKey = "Pause.png";
            this.btnPause.ImageList = this.imgLstIcons;
            this.btnPause.Location = new System.Drawing.Point(88, 293);
            this.btnPause.Margin = new System.Windows.Forms.Padding(2);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(75, 81);
            this.btnPause.TabIndex = 5;
            this.btnPause.UseVisualStyleBackColor = true;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // btnExit
            // 
            this.btnExit.ImageKey = "Exit.png";
            this.btnExit.ImageList = this.imgLstIcons;
            this.btnExit.Location = new System.Drawing.Point(267, 292);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 81);
            this.btnExit.TabIndex = 6;
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // tmrGameTime
            // 
            this.tmrGameTime.Interval = 350;
            this.tmrGameTime.Tick += new System.EventHandler(this.tmrGameTime_Tick);
            // 
            // grpBxInfo
            // 
            this.grpBxInfo.Controls.Add(this.btnLoad);
            this.grpBxInfo.Controls.Add(this.btnSave);
            this.grpBxInfo.Controls.Add(this.lstBxUnitInfo);
            this.grpBxInfo.Controls.Add(this.btnPlay);
            this.grpBxInfo.Controls.Add(this.btnPause);
            this.grpBxInfo.Controls.Add(this.btnExit);
            this.grpBxInfo.Controls.Add(this.lblElapsedTime);
            this.grpBxInfo.Controls.Add(this.lblTimeStamp);
            this.grpBxInfo.Font = new System.Drawing.Font("ROG Fonts", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBxInfo.Location = new System.Drawing.Point(790, 2);
            this.grpBxInfo.Margin = new System.Windows.Forms.Padding(2);
            this.grpBxInfo.Name = "grpBxInfo";
            this.grpBxInfo.Padding = new System.Windows.Forms.Padding(2);
            this.grpBxInfo.Size = new System.Drawing.Size(346, 410);
            this.grpBxInfo.TabIndex = 8;
            this.grpBxInfo.TabStop = false;
            this.grpBxInfo.Text = "Timer + Unit Info";
            // 
            // btnLoad
            // 
            this.btnLoad.BackColor = System.Drawing.SystemColors.Window;
            this.btnLoad.Location = new System.Drawing.Point(88, 379);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(75, 23);
            this.btnLoad.TabIndex = 8;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = false;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.Window;
            this.btnSave.Location = new System.Drawing.Point(9, 379);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lstBxUnitInfo
            // 
            this.lstBxUnitInfo.Font = new System.Drawing.Font("ROG Fonts", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstBxUnitInfo.FormattingEnabled = true;
            this.lstBxUnitInfo.ItemHeight = 17;
            this.lstBxUnitInfo.Location = new System.Drawing.Point(9, 46);
            this.lstBxUnitInfo.Margin = new System.Windows.Forms.Padding(2);
            this.lstBxUnitInfo.Name = "lstBxUnitInfo";
            this.lstBxUnitInfo.Size = new System.Drawing.Size(333, 242);
            this.lstBxUnitInfo.TabIndex = 3;
            // 
            // frmRTSMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(1138, 977);
            this.Controls.Add(this.grpBxInfo);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmRTSMain";
            this.Text = "My RTS Game";
            this.Load += new System.EventHandler(this.frmRTSMain_Load);
            this.grpBxInfo.ResumeLayout(false);
            this.grpBxInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblElapsedTime;
        private System.Windows.Forms.Label lblTimeStamp;
        private System.Windows.Forms.ImageList imgLstIcons;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Timer tmrGameTime;
        private System.Windows.Forms.GroupBox grpBxInfo;
        private System.Windows.Forms.ListBox lstBxUnitInfo;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnSave;
    }
}

